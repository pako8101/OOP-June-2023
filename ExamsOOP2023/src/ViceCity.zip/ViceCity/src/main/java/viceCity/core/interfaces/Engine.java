package ViceCity.src.main.java.viceCity.core.interfaces;

public interface Engine extends Runnable {
}
