package ViceCity.src.main.java.viceCity.models.players;


public class MainPlayer extends BasePlayer{
    private static final int MAIN_LIFE_POINTS = 100;
            private static final String MAIN_NAME = "Tommy Vercetti";
    public MainPlayer() {
        super(MAIN_NAME, MAIN_LIFE_POINTS);
    }


}
